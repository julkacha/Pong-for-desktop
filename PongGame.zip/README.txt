To play go to 'dist --> PongGame' folder and choose PongGame.exe (You can create a shortcut in the main folder)
--> Use w, s, up and down to move (or click on the screen)
--> SPACEBAR to pause the game (or PAUSE on the screen)
--> ENTER to restart the game